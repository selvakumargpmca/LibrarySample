﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibrarySystem
{
    public partial class _Default : System.Web.UI.Page
    {
        OleDbConnection con = new OleDbConnection(ConfigurationManager.ConnectionStrings["DBCONN"].ConnectionString);
        OleDbCommand cmd;
        OleDbDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            NavigationMenu.Visible = false;
            Session["UserName"] = null;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new OleDbCommand("select * from UserAccess where Name = @Name and Password = @Password", con);
                OleDbParameter param1 = new OleDbParameter("Name", SqlDbType.VarChar);
                param1.Value = TextBox1.Text;
                cmd.Parameters.Add(param1);
                OleDbParameter param2 = new OleDbParameter("Password", SqlDbType.VarChar);
                param2.Value = TextBox2.Text;
                cmd.Parameters.Add(param2);
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Session["UserName"] = dr.GetString(1);
                    Session["AccessType"] = dr.GetString(3);
                    Response.Redirect("~/Librarian.aspx");
                }
                else
                    Response.Write("UserName or Password does not exist");
            }
            catch (Exception ex) { Response.Write(ex.Message); }
        }
    }
}
