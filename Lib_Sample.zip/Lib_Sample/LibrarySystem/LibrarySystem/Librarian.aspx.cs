﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace LibrarySystem
{
    public partial class Librarian : System.Web.UI.Page
    {
        static string mode;
        OleDbConnection con = new OleDbConnection(ConfigurationManager.ConnectionStrings["DBCONN"].ConnectionString);
        OleDbCommand cmd;
        OleDbDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] == null)
            {
                Response.Redirect("/Default.aspx");
            }
            if (!IsPostBack)
            {
                DrpLoad();

                if (Session["AccessType"] != null && Session["AccessType"].ToString() == "Admin")
                {
                    MenuItem M1, M2, M3;
                    M1 = new MenuItem("ADD BOOK", "ADD BOOK", "", "~/Librarian.aspx?mode=addbook", "");
                    M2 = new MenuItem("SEARCH BOOK", "SEARCH BOOK", "", "~/Librarian.aspx?mode=searchbook", "");
                    M3 = new MenuItem("LOGOUT", "LOGOUT", "", "~/Default.aspx", "");
                    NavigationMenu.Items.Add(M1);
                    NavigationMenu.Items.Add(M2);
                    NavigationMenu.Items.Add(M3);
                }
                else if (Session["AccessType"] != null && Session["AccessType"].ToString() == "User")
                {
                    MenuItem M1,M2;
                    M1 = new MenuItem("SEARCH BOOK", "SEARCH BOOK", "", "~/Librarian.aspx?mode=searchbook", "");
                    M2 = new MenuItem("LOGOUT", "LOGOUT", "", "~/Default.aspx", "");
                    NavigationMenu.Items.Add(M1);
                    NavigationMenu.Items.Add(M2);
                }

                try
                {
                    mode = Request.QueryString["mode"].ToString();
                    if (mode == "addbook")
                    {
                        divwlcm.Style.Add("display", "none");
                        divsrcbook.Style.Add("display", "none");
                        divaddbook.Style.Add("display", "block");
                    }
                    else if (mode == "searchbook")
                    {
                        divwlcm.Style.Add("display", "none");
                        divsrcbook.Style.Add("display", "block");
                        divaddbook.Style.Add("display", "none");
                    }
                }
                catch (Exception ex)
                {
                }
            }
        }

        private void DrpLoad()
        {
            con.Open();
            OleDbDataAdapter OleAdp = new OleDbDataAdapter("select ID, BookCategory from BookCategory", con);
            DataSet ds = new DataSet();
            OleAdp.Fill(ds);
            con.Close();

            for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
            {
                drpCategory.Items.Add(new ListItem(ds.Tables[0].Rows[i][1].ToString(), ds.Tables[0].Rows[i][0].ToString()));
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new OleDbCommand("Insert into Book(BookCategoryID,BookName,AuthorName,Edition,Price) values('" + drpCategory.SelectedValue.ToString() + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "')", con);
            cmd.ExecuteNonQuery();
            TextBox2.Text = TextBox3.Text = TextBox4.Text = TextBox5.Text = "";
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbDataAdapter OleAdp = new OleDbDataAdapter("select B.ID,B.BookName,B.AuthorName,C.BookCategory,B.Edition,B.Price from Book B, BookCategory C where B.BookCategoryID = C.ID and BookName like '%" + txtsrcstdnt.Text + "%'", con);
            DataSet ds = new DataSet();
            OleAdp.Fill(ds);
            con.Close();
            grdLibrary.DataSource = ds;
            grdLibrary.DataBind();
        }

    }
}